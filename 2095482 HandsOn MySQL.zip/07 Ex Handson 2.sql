USE University_Management_System;

SELECT si.Reg_Number, si.Student_Name, sm.Subject_Code, sm.Marks			-- Exercise 1
FROM Student_Info AS si INNER JOIN Student_Marks AS sm
WHERE si.Reg_Number = sm.Reg_Number;

SELECT si.Reg_Number, si.Student_Name, sm.Subject_Code, sm.Marks			--  Exercise 2
FROM Student_Info AS si INNER JOIN Student_Marks AS sm
ON si.Reg_Number = sm.Reg_Number
WHERE (sm.Marks > 65) ORDER BY sm.Marks;

SELECT si.Reg_Number, si.Student_Name, sr.GPA						--  Exercise 3
FROM Student_Info AS si INNER JOIN Student_Result AS sr
ON si.Reg_Number = sr.Reg_Number
ORDER BY sr.GPA DESC LIMIT 1;

ALTER TABLE Student_Info
DROP COLUMN Age;

CREATE TABLE Backup_Student_Info							-- P 4
(
	Reg_Number  Varchar(20) Primary Key,
    CONSTRAINT Bsi_Reg_Number
	FOREIGN KEY (reg_number) REFERENCES student_info(reg_number),
    Student_Name  Varchar(30) NOT NULL,
	Branch  Varchar(30),
	Contact_Number  Varchar(20),
	Date_of_Birth Date  NOT NULL,
	Date_of_Joining Date,
	Address Varchar(250),
	Email_id Varchar(250)
);

SELECT * FROM Backup_Student_Info;				

INSERT INTO backup_student_info 
SELECT * FROM student_info;

INSERT INTO student_info(Reg_Number, Student_name, Branch, Contact_number, Date_of_Birth, Date_of_Joining, Address, Email_Id) 
VALUES
    ('1BI17EI028' ,'Rohith', 'EIE' ,'8064589788', '1923-10-12', '2012-4-11', '8/4,3rd cross vidyaranyapura', 'rohithms@gmail.com'),
	('1BI17EI007' ,'Rahul', 'ECE' ,'9873549802', '1923-12-02', '2012-5-10', '84, 1st Block Marathalli', 'rahulkamboj@gmail.com');
    
SELECT * FROM student_info AS si 
LEFT OUTER JOIN Backup_Student_Info AS bsi 
ON si.Reg_Number = bsi.Reg_Number;

SELECT * FROM student_info AS si 							-- P 5
RIGHT OUTER JOIN Backup_Student_Info AS bsi 
ON si.Reg_Number = bsi.Reg_Number;