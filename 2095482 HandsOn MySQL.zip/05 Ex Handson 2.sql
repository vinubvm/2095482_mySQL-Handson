USE University_Management_System;
								
SELECT *,														-- P 1
UPPER(Student_Name) AS CAP_Std_Name,UPPER(Branch) AS CAP_Branch
FROM Student_info;

SELECT *,														-- P 2
LOWER(Subject_Code) AS SAM_Sub_Code, LOWER(Subject_Name) AS SAM_Sub_Name
FROM Subject_Master;

-- DECLARE @Date_of_Birth DATE = 'yyyy/mm/dd';
SELECT Date_of_birth FROM Student_Info;

SELECT DATE_FORMAT(Date_Of_Birth, '%y/%m/%d')					-- P 3 a
FROM Student_Info;
SELECT DATE_FORMAT(Date_Of_Birth, '%b /%d /%y')					-- P 3 b
FROM Student_Info;

SELECT Student_Name, Contact_Number,Email_Id,						-- P 4
Round(((DateDiff(curdate(),Date_of_Birth)/30)/12),0) AS Age
FROM Student_Info;
  
SELECT si.Reg_Number, si.Student_Name,si.Branch, sm.Semester ,ROUND(AVG(sm.marks),2)			-- P 5
FROM Student_Info AS si INNER JOIN Student_Marks AS sm 
WHERE si.Reg_Number = sm.Reg_Number 
GROUP BY sm.semester,si.student_name ORDER BY si.student_name;
  
SELECT si.Reg_Number, si.Student_Name,sm.Semester,							-- P 6
MAX(sm. Marks) AS Max_Marks
FROM Student_Info AS si INNER JOIN Student_Marks AS sm
WHERE si.Reg_Number = sm.Reg_Number
GROUP BY Reg_Number,Semester ORDER BY si.student_name;

SELECT si.Reg_Number, si.Student_Name,sm.Subject_Code,							-- P 7
MAX(sm. Marks) AS Max_Marks
FROM Student_Info AS si INNER JOIN Student_Marks AS sm
WHERE si.Reg_Number = sm.Reg_Number AND sm.Subject_code = 'EI05IP';

SELECT Semester,round(AVG(GPA),2) AS Avg_GPA FROM Student_result 			-- P 8 
GROUP BY semester ;

SELECT Reg_Number,Student_Name,Branch,Contact_Number,date_of_birth,Date_of_Joining,address,			-- P 9
CASE
	WHEN Email_Id IS NULL THEN 'no valid email address'
	ELSE Email_Id	
END AS Email_Status
FROM Student_Info;		

SELECT si.Reg_Number,si.Student_Name,si.Branch,sm.Semester,						-- P 10
CASE
	WHEN si.Branch = 'EIE' THEN 'Electronics and Instrumentation Engineering'
    WHEN si.Branch = 'EI' THEN 'Electronics and Instrumentation Engineering'
    WHEN si.Branch = 'MBA' THEN 'Management of Business Administration'
    WHEN si.Branch = 'ECE' THEN 'Electronics and Communication Engineering'
	ELSE 'Other Branch'
END AS Branch_Name
FROM Student_info AS si INNER JOIN Student_Marks AS sm 
WHERE si.Reg_Number = sm.Reg_Number
GROUP BY si.Student_name, sm.Semester
ORDER BY si.Student_name;